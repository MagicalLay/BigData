package epissageConsensus;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.io.BufferedReader;
import java.io.FileReader;

public class traitementARN {
	
	public StringBuilder[] readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder[] sb = new StringBuilder[20];
	        String line = br.readLine();
	        int i = 0;
	        
	        while (line != null) {
	        	//System.out.println(i);
	            line = br.readLine();

	        	//System.out.println(line);
	            sb[i]=new StringBuilder(line);
	            line = br.readLine();
	            i++;
	        }
	        return sb;
	    } finally {
	        br.close();
	    }
	}
	   
	public String seqPlusCourante(String[] st, int lg){
		int[] nbSim = new int[lg];
		for(int i = 0 ; i<lg ; i++){
			nbSim[i]=0;
			for(int j = 0 ; j<lg ; j++){
				if(st[i].equals(st[j]))
				{
					nbSim[i]+=1;
				}
			}
		}
		int max = 1;
		int maxIdent = 0;
		int k;
		for(k = 0 ; k<lg ; k++)
		{
			if(nbSim[k]>max) {
				max = nbSim[k];
				maxIdent=k;
			}
		}
		if(max==1){
			return "equals";
		}
		else{
			return st[maxIdent];
		}
	}
	
	public static void main(String[] args) throws IOException{
		
		traitementARN instance = new traitementARN();
		
		int nbpeople = 4;
		StringBuilder[] br1 = instance.readFile("arns1");
		StringBuilder[] br2 = instance.readFile("arns2");
		StringBuilder[] br3 = instance.readFile("arns3");
		StringBuilder[] br4 = instance.readFile("arns4");
		StringBuilder[] adn1 = instance.readFile("adns1");
		StringBuilder[] adn2 = instance.readFile("adns2");
		StringBuilder[] adn3 = instance.readFile("adns3");
		StringBuilder[] adn4 = instance.readFile("adns4");
		System.out.println(adn1[0].toString());
		System.out.println(adn2[0].toString());
		//System.out.println(adn3[0].toString());
		System.out.println(adn4[0].toString()+"\n");
		
		int[] pos1 = new int[20];
		for (int i = 0 ; i<20 ; i++){
			pos1[i]=0;
		}
		String[] etapes = new String[20];
		String res1 ="";
		String chaine;
		boolean regle = true;
		
		while(regle){
			for(int i = 0 ; i<20 ; i++){
				if(pos1[i]>=br1[i].length()){
					etapes[i]=""+i;
				}
				else{
					etapes[i] = ""+br1[i].charAt(pos1[i]);
				}
			}
			chaine = instance.seqPlusCourante(etapes, 20);
			//System.out.println(chaine);
			res1=res1+chaine;
			for(int j = 0 ; j<20 ; j++){
				if(etapes[j].equals(chaine)){
					pos1[j]++;
				}
			}
			int test = 0;
			for(int k =0 ; k<20 ; k++){
				if(pos1[k]>=br1[k].length()){
					test++;
				}
			}
			if(test==20){
				regle=false;
			}
		}

		System.out.println(res1);
		
		int[] pos2 = new int[20];
		for (int i = 0 ; i<20 ; i++){
			pos2[i]=0;
		}
		String res2 ="";
		regle = true;
		
		while(regle){
			for(int i = 0 ; i<20 ; i++){
				if(pos2[i]>=br2[i].length()){
					etapes[i]=""+i;
				}
				else{
					etapes[i] = ""+br2[i].charAt(pos2[i]);
				}
			}
			chaine = instance.seqPlusCourante(etapes, 20);
			//System.out.println(chaine);
			res2=res2+chaine;
			for(int j = 0 ; j<20 ; j++){
				if(etapes[j].equals(chaine)){
					pos2[j]++;
				}
			}
			int test = 0;
			for(int k =0 ; k<20 ; k++){
				if(pos2[k]>=br2[k].length()){
					test++;
				}
			}
			if(test==20){
				regle=false;
			}
		}

		System.out.println(res2);
		
		int[] pos3 = new int[20];
		for (int i = 0 ; i<20 ; i++){
			pos3[i]=0;
		}
		String res3 ="";
		regle = true;/*
		
		while(regle){
			for(int i = 0 ; i<20 ; i++){
				if(pos3[i]>=br3[i].length()){
					etapes[i]=""+i;
				}
				else{
					etapes[i] = ""+br3[i].charAt(pos3[i]);
				}
			}
			chaine = instance.seqPlusCourante(etapes, 20);
			//System.out.println(chaine);
			res3=res3+chaine;
			for(int j = 0 ; j<20 ; j++){
				if(etapes[j].equals(chaine)){
					pos3[j]++;
				}
			}
			int test = 0;
			for(int k =0 ; k<20 ; k++){
				if(pos3[k]>=br3[k].length()){
					test++;
				}
			}
			if(test==20){
				regle=false;
			}
		}

		System.out.println(res3);*/
		
		int[] pos4 = new int[20];
		for (int i = 0 ; i<20 ; i++){
			pos4[i]=0;
		}
		String res4 ="";
		regle = true;
		
		while(regle){
			for(int i = 0 ; i<20 ; i++){
				if(pos4[i]>=br4[i].length()){
					etapes[i]=""+i;
				}
				else{
					etapes[i] = ""+br4[i].charAt(pos4[i]);
				}
			}
			chaine = instance.seqPlusCourante(etapes, 20);
			//System.out.println(chaine);
			res4=res4+chaine;
			for(int j = 0 ; j<20 ; j++){
				if(etapes[j].equals(chaine)){
					pos4[j]++;
				}
			}
			int test = 0;
			for(int k =0 ; k<20 ; k++){
				if(pos4[k]>=br4[k].length()){
					test++;
				}
			}
			if(test==20){
				regle=false;
			}
		}

		System.out.println(res4);
		/*
		for (int i = 0 ; i<20 ; i++){
			pos1[i]=0;
		}
		res1 ="";
		regle = true;
		
		while(regle){
			for(int i = 0 ; i<20 ; i++){
				if(pos1[i]>=br1[i].length()-1){
					etapes[i]=""+i;
				}
				else{
					etapes[i] = br1[i].substring(pos1[i], pos1[i]+1);
				}
			}
			chaine = instance.seqPlusCourante(etapes, 20);
			//System.out.println(chaine);
			res1=res1+chaine.charAt(0);
			for(int j = 0 ; j<20 ; j++){
				if(etapes[j].equals(chaine)){
					pos1[j]++;
				}
			}
			int test = 0;
			for(int k =0 ; k<20 ; k++){
				if(pos1[k]>=br1[k].length()-1){
					test++;
				}
			}
			if(test==20){
				regle=false;
			}
		}
		
		System.out.println(res1);
		*/
		
		
		
	}
}
